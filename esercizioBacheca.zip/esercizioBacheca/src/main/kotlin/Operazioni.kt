class Operazioni {





    fun menuAdmin(){

        var menuAdminChoice = 0                     // inizializzo variabile a 0 per la scelta da fare nel menu
        println("scegli un opzione:")
        println("Visualizza Utenze : 1")
        println("Modifica Annunci : 2")
        println("Elimina Annunci : 3")
        println("Esci : 4")
        menuAdminChoice = readLine()!!.toInt()      // lettura da input della variabile menuAdminChoice

        //var tryMenu = false                       // inizializzo variabile a FALSE per uscita dal ciclo
        when (menuAdminChoice) {                              // menu CRUD scelta 1,2,3,4


            1 -> {
                Bacheca().visualizzaUtenze() // da fare
            }


            2 -> {
                Bacheca().modificaAnnuncio()
            }

            3 -> {
                Bacheca().eliminaAnnuncio()
            }

            4 -> {                                              // APERTURA DELL'EXIT
                println("Esci")
                var usernameChance = ""
                var pswChance = ""
                //tryMenu == false
                //exit == false
                // || system.exit(-1)
            }                                                   // CHIUSURA DELL'EXIT

        }                                               // CHIUSURA WHEN menu CRUD scelta 1,2,3,4 r.85


    } // CHIUSURA se le credenziali sono corrette, menu admin con CRUD r.71







    fun menuUser(){

        var menuUserChoice = 0
        println("scegli un opzione:")
        println("Pubblica annuncio : 1")
        println("Commenta annuncio : 2")
        println("Compra annuncio : 3")
        println("Esci : 4")
        menuUserChoice = readLine()!!.toInt()      // lettura da input della variabile menuAdminChoice

        when (menuUserChoice) {                              // menu CRUD scelta 1,2,3,4


            1 -> {
                Bacheca().aggiungiAnnuncio()
            }


            2 -> {
                Bacheca().commentaAnnuncio()
            }


            3 -> {
                Bacheca().compraAnnuncio()
            }

            4 -> {                                              // APERTURA DELL'EXIT
                println("Esci")
                var usernameChance = ""
                var pswChance = ""
                //tryMenu == false
                // OR system.exit(-1)
            }                                                   // CHIUSURA DELL'EXIT

        }


    }

}