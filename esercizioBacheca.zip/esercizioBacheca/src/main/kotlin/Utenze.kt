import java.util.ArrayList

class Utenze(){//var username: String, var psw: String){

    var loop = true


        fun LogIn (){//usenameArrayList: ArrayList<String>, pswArrayList: ArrayList<String>){

            do{
            var usernameA = arrayListOf<String>()
            var pswA = arrayListOf<String>()
            var username = ""
            var psw = ""
            println("inserisci credenziali...")
            println()
            username = readLine()!!.toString()
            usernameA.add(username)
            println("username inserito")
            psw = readLine()!!.toString()
            pswA.add(psw)
            println("password inserita")

            if (username.equals("Root") && psw.equals("Toor")){
                Operazioni().menuAdmin()
            }
            else {
                Operazioni().menuUser()
            }
        }while( loop == true)

        }

    }


//  potrei creare array utente & psw in posizione fissa [0] non deleteble che sarà Admin onde evitare errori
//  in questo modo potrei anche implementare il copy-position usato in esQuizzone:



// IN QUESTO MODO L'UTENTE E' COSTRETTO A COMPILARE ENTRAMBE LE VOCI NELL'ITERATORE DEFINITO. SI PUO' AGGIUNGERE CICLO FINCHE' NON FACCIA
// CORRETTAMENTE CIO' CHE RICHIESTO. STESSA OPERAZIONE VALIDA PER : MODIICA, AGGIUNGI, ELIMINA. C.R.U.D