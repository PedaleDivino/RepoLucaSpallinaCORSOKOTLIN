class Bacheca() {

    var annuncio = ArrayList<String>()
    var sceltaContinua = ""
    var tryCycle = false
    var titoloAnnuncio = ""
    var descrizioneAnnuncio = ""
    var prezzoAnnuncio = 0
    var commentoAnnuncio = ""


        fun aggiungiAnnuncio() {

            while(tryCycle == true) {
                println("Aggiungi un annuncio")
                titoloAnnuncio =
                    readLine()!!.toString()              // popolo variabile domandaAdmin con INPUT da ADMIN
                annuncio.add(titoloAnnuncio)                           // utilizzo del metodo add per aggiungere domande nell'array 'domande'
                println("Aggiungi una descrizione")
                descrizioneAnnuncio = readLine()!!.toString()
                annuncio.add(descrizioneAnnuncio)
                prezzoAnnuncio = readLine()!!.toInt()
                annuncio.add(prezzoAnnuncio.toString())
                annuncio.add(commentoAnnuncio)

                println("continuare? y/n")
                sceltaContinua = readLine()!!.toString()            // richiedo da input se continuare o meno con utilizzo della variabile sceltaContinua


                if (sceltaContinua.equals("y")) {                   // se "y" non va fuori dal CICLO WHILE a R.92
                    tryCycle = true
                }                                                   // fine prima condizione
                else {                                               // qualsiasi cosa tu scriva starà dentro il CICLO WHILE R.92
                    tryCycle = false
                }
            }
        }

        fun commentaAnnuncio() {

            while(tryCycle == true)
            println("quale annuncio vuoi commentare?")
            var i = 0                                                       // iterare domande
            var a = 0                                                       // inizializzo variabile vuota per poter modificare domanda scelta da INPUT
            var max = annuncio.size
            while (i < max) {                                               // inizializzo variabile vuota per poter modificare domanda scelta da INPUT
                println(annuncio.get(i) + " ["+i+"]")                          // mostra array domande tramite il metodo .size
                i++
            }
            a = readLine()!!.toInt()                            // legge da INPUT l'indice dell'array delle domande. così che possa modificare la domanda richiesta
            i = a
            println(annuncio.get(i))                             // lettura INDICE array, corrispondenza con la domanda scelta
            println("commenta l'annuncio...")
            commentoAnnuncio = readLine()!!.toString()
            annuncio.add(i, commentoAnnuncio)

            println("continuare? y/n")
            sceltaContinua = readLine()!!.toString()            // richiedo da input se continuare o meno con utilizzo della variabile sceltaContinua

            if (sceltaContinua.equals("y")) {                   // se "y" non va fuori dal CICLO WHILE a R.92
                tryCycle = true
            }                                                   // fine prima condizione
            else {                                               // qualsiasi cosa tu scriva starà dentro il CICLO WHILE R.92
                tryCycle = false
            }


        }

        fun compraAnnuncio() {

            var crediti = 1000
            var creditiUpdated : Int
            println("il tuo budget e' $crediti")
            var i = 0                                                       // iterare domande
            var a = 0                                                       // inizializzo variabile vuota per poter modificare domanda scelta da INPUT
            var max = annuncio.size
            while (i < max) {                                               // inizializzo variabile vuota per poter modificare domanda scelta da INPUT
                println(annuncio.get(i) + " ["+i+"]")                          // mostra array domande tramite il metodo .size
                i++
            }
            a = readLine()!!.toInt()
            i = a
            println(annuncio.get(i))                             // lettura INDICE array, corrispondenza con la domanda scelta
            println("vuoi comprare l'annuncio $i...")
            if (crediti <= prezzoAnnuncio){
                creditiUpdated = crediti - prezzoAnnuncio
                println("hai $creditiUpdated")
            } else {
                println("non hai abbastanza crediti...")
            }

        }


    //fun operazioniBachecaAdmin()


        fun visualizzaUtenze(){
            println("Ecco a te le utenze...")

        }


        fun modificaAnnuncio() {

            while (tryCycle == true) {
                println("quale annuncio vuoi modificare?")
                var i = 0                                                       // iterare domande
                var a =
                    0                                                       // inizializzo variabile vuota per poter modificare domanda scelta da INPUT
                var max = annuncio.size
                while (i < max) {                                               // inizializzo variabile vuota per poter modificare domanda scelta da INPUT
                    println(annuncio.get(i) + " [" + i + "]")                          // mostra array domande tramite il metodo .size
                    i++
                }
                a =
                    readLine()!!.toInt()                            // legge da INPUT l'indice dell'array delle domande. così che possa modificare la domanda richiesta
                i = a
                println(annuncio.get(i))                             // lettura INDICE array, corrispondenza con la domanda scelta
                println("modifica l'annuncio...")
                println("modifica il titolo")
                titoloAnnuncio = readLine()!!.toString()
                annuncio.set(i, titoloAnnuncio)
                println("modifica una descrizione")
                descrizioneAnnuncio = readLine()!!.toString()
                annuncio.set(i, descrizioneAnnuncio)
                println("modifica prezzo annuncio")
                prezzoAnnuncio = readLine()!!.toInt()
                annuncio.set(i, prezzoAnnuncio.toString())
                annuncio.set(i, commentoAnnuncio)

                println("continuare? y/n")
                sceltaContinua =
                    readLine()!!.toString()            // richiedo da input se continuare o meno con utilizzo della variabile sceltaContinua

                if (sceltaContinua.equals("y")) {                   // se "y" non va fuori dal CICLO WHILE a R.92
                    tryCycle = true
                }                                                   // fine prima condizione
                else {                                               // qualsiasi cosa tu scriva starà dentro il CICLO WHILE R.92
                    tryCycle = false
                }
            }
        }


        fun eliminaAnnuncio() {

            while (tryCycle == true) {
                println("quale annuncio vuoi eliminare?")
                var i = 0                                                       // iterare domande
                var a = 0                                                       // inizializzo variabile vuota per poter modificare domanda scelta da INPUT
                var max = annuncio.size
                while (i < max) {                                               // inizializzo variabile vuota per poter modificare domanda scelta da INPUT
                    println(annuncio.get(i) + " [" + i + "]")                          // mostra array domande tramite il metodo .size
                    i++
                }
                a = readLine()!!.toInt()                            // legge da INPUT l'indice dell'array delle domande. così che possa modificare la domanda richiesta
                i = a
                println(annuncio.get(i))                             // lettura INDICE array, corrispondenza con la domanda scelta
                println("stai eliminando l'annuncio...")
                annuncio.removeAt(a)
                println("continuare? y/n")
                sceltaContinua =
                    readLine()!!.toString()            // richiedo da input se continuare o meno con utilizzo della variabile sceltaContinua

                if (sceltaContinua.equals("y")) {                   // se "y" non va fuori dal CICLO WHILE a R.92
                    tryCycle = true
                }                                                   // fine prima condizione
                else {                                               // qualsiasi cosa tu scriva starà dentro il CICLO WHILE R.92
                    tryCycle = false
                }
            }
        }


        }


/*
println("scegli un opzione:")
        println("Visualizza Utenze : 1")
        println("Modifica Annunci : 2")
        println("Elimina Annunci : 3")
        println("Esci : 4")
 */